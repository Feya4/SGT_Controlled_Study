# Experimental results

`BRACS_CAMELYON16/comparison_terminal_output.txt`, `BACH/comparison_terminal_output.txt`, and `ISIC2018/comparison_terminal_output.txt` are **user-provided terminal output**, not re-run validated experiments. The combined BRACS/CAMELYON16 log includes older configurations and different runs; inspect checkpoint-selection rule and dataset before quoting.

For publication, provide downloadable per-seed predictions and split manifests beside these logs. Results from the public Feya4/SGT repository may correspond to an earlier experimental design and must not silently replace revised-paper results.
